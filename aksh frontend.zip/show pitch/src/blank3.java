import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class blank3 extends JFrame {

    private JComboBox<String> comboBox;
    private Image backgroundImage;

    public blank3() {
        // Load the background image
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\drivi\\OneDrive\\Desktop\\vite trial1\\show pitch\\show pitch\\src\\519.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set up the frame
        setTitle("Blank Page 3");
        setSize(650, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Custom panel with background image
        BackgroundPanel mainPanel = new BackgroundPanel();
        mainPanel.setLayout(new GridBagLayout()); // Center components in the panel

        // Create a panel for the title and combo box to align them vertically
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setOpaque(false); // Transparent panel to show background
// Title label at the top
JLabel titleLabel = new JLabel("What u got in der?", SwingConstants.CENTER);
titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 50));
titleLabel.setForeground(Color.WHITE); // Set font color to white
titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Center-align in box layout

        // Initialize JComboBox with an empty list and add KeyListener
        String[] items = {};
        comboBox = new JComboBox<>(items);
        comboBox.setEditable(true);
        comboBox.setPreferredSize(new Dimension(250, 30));
        comboBox.setMaximumSize(new Dimension(250, 30)); // Set maximum size to keep it centered

        comboBox.getEditor().getEditorComponent().addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    String input = (String) comboBox.getEditor().getItem();
                    if (input != null && !input.trim().isEmpty()) {
                        comboBox.addItem(input);
                        comboBox.setSelectedItem("");
                    }
                }
            }
        });

        // Add components to the center panel
        centerPanel.add(titleLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer between label and combo box
        centerPanel.add(comboBox);

        // Add center panel to the main panel and center it
        mainPanel.add(centerPanel, new GridBagConstraints());

        // Set main panel as content pane to display background
        setContentPane(mainPanel);

        // Display the frame
        setVisible(true);
    }

    // Custom panel to paint the background image
    private class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        new blank3();
    }
}
