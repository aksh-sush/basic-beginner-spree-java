import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class blank2nd extends JFrame {

    private JButton simpleButton1;
    private JButton simpleButton2;
    private JButton simpleButton3;
    private Icon buttonIcon1, buttonIcon2, buttonIcon3; // Placeholder for icons

    public blank2nd() {
        // Set up the frame for the blank page
        setTitle("Blank Page");
        setSize(650, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Use null layout for absolute positioning

        // Create a panel for two buttons at the top
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 20)); // Centered alignment with gaps
        buttonPanel.setBounds(0, 0, 650, 80); // Position the panel at the top

        // Create the two top buttons
        JButton button1 = new JButton("MODE: CARNIVORE");
        JButton button2 = new JButton("MODE: HERBIVORE");
        
        button1.setForeground(Color.RED);
        button2.setForeground(new Color(0, 128, 0));
        button1.setBackground(Color.LIGHT_GRAY);
        button2.setBackground(Color.LIGHT_GRAY);

        // Add buttons to the panel
        buttonPanel.add(button1);
        buttonPanel.add(button2);

        // Add the panel to the frame
        add(buttonPanel);

        // Initialize the "APPETIZER" button
        simpleButton1 = new JButton("APPETIZER");
        simpleButton1.setBounds(200, 120, 250, 100);
        simpleButton1.setIcon(buttonIcon1);
        simpleButton1.setHorizontalTextPosition(JButton.CENTER);
        simpleButton1.setVerticalTextPosition(JButton.CENTER);
        simpleButton1.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton1.setIconTextGap(0);
        simpleButton1.setForeground(Color.cyan);
        simpleButton1.setBackground(Color.lightGray);
        simpleButton1.setBorder(BorderFactory.createEtchedBorder());
        
        // Add an ActionListener to open Blank3 on click
        simpleButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new blank3(); // Create and display a new Blank3 frame
            }
        });

        // Initialize the "ENTREE" button
        simpleButton2 = new JButton("ENTREE");
        simpleButton2.setBounds(200, 240, 250, 100);
        simpleButton2.setIcon(buttonIcon2);
        simpleButton2.setHorizontalTextPosition(JButton.CENTER);
        simpleButton2.setVerticalTextPosition(JButton.CENTER);
        simpleButton2.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton2.setIconTextGap(0);
        simpleButton2.setForeground(Color.cyan);
        simpleButton2.setBackground(Color.lightGray);
        simpleButton2.setBorder(BorderFactory.createEtchedBorder());

        simpleButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new blank3(); // Create and display a new Blank3 frame
            }
        });

        // Initialize the "DESSERT" button
        simpleButton3 = new JButton("DESSERT");
        simpleButton3.setBounds(200, 360, 250, 100);
        simpleButton3.setIcon(buttonIcon3);
        simpleButton3.setHorizontalTextPosition(JButton.CENTER);
        simpleButton3.setVerticalTextPosition(JButton.CENTER);
        simpleButton3.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton3.setIconTextGap(0);
        simpleButton3.setForeground(Color.cyan);
        simpleButton3.setBackground(Color.lightGray);
        simpleButton3.setBorder(BorderFactory.createEtchedBorder());

        simpleButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new blank3(); // Create and display a new Blank3 frame
            }
        });

        // Add the recipe buttons to the frame
        add(simpleButton1);
        add(simpleButton2);
        add(simpleButton3);

        // Set frame visibility
        setVisible(true);
    }

    public static void main(String[] args) {
        new blank2nd(); // Create and display the frame
    }
}
